### Hexlet tests and linter status:
[![Actions Status](https://github.com/GregorKurkin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GregorKurkin/python-project-49/actions)

<a href="https://codeclimate.com/github/GregorKurkin/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/402be1b0e2b3764baaf0/maintainability" /></a>

### Video of BRAIN-EVEN
https://asciinema.org/a/toLHRv9yB58ZtP83dOOezPjIU
